lex 4.l
yacc -Wno-all -dvtg 4.y
gcc -w lex.yy.c y.tab.c -ll -ly -lm
./a.out<quick_sort.py
